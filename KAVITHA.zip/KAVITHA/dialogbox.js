angular.module('dialogDemo2', ['ngMaterial'])
.config(function($mdIconProvider) {
  $mdIconProvider
    .iconSet("call", 'img/icons/sets/communication-icons.svg', 24)
    .iconSet("social", 'img/icons/sets/social-icons.svg', 24);
})
.controller('AppCtrl', function($scope, $mdDialog) {
  $scope.openFromLeft = function() {
    $mdDialog.show(
      $mdDialog.alert()
        .clickOutsideToClose(true)
        .title('congrat!!!Continue learning')
        .textContent('Happy Learning!')
        .ariaLabel('Left to right demo')
        .ok('Learn!')
        .openFrom('#left')
        .closeTo(angular.element(document.querySelector('#right')))
    );
  };
  var vm = this;

  this.announceClick = function(index) {
    $mdDialog.show(
      $mdDialog.alert()
        .title('You clicked!')
        .textContent('You clicked the menu item at index ' + index)
        .ok('Learn')
    );
  };
// $scope.openOffscreen = function() {
//     $mdDialog.show(
//       $mdDialog.alert()
//         .clickOutsideToClose(true)
//         .title('Can learn at late time')
//         .textContent('Waiting for ur interest')
//         .ariaLabel('Offscreen Demo')
//         .ok('start!')
//         .openFrom({
//           top: -50,
//           width: 30,
//           height: 80
//         })
//         .closeTo({
//           left: 1500
//         })
//     );
//   };
});
